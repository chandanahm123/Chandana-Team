using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApp4
{
	class Program
	{
        // deptid1 is used to store the fetched deptid from department file.
        //mngrid is used to store the fetched manager id from projects file.
        public static string deptid1 = " ", mngrid = " ";
		static void Main(string[] args)
		{
			int flag = 1;
			while (flag == 1)
			{
				int ch;
				Console.Write("\n" + "1. insert employee / department / projects");
				Console.Write("\n" + "2.searching the employees with common department");
				Console.Write("\n" + "3.search by empid in projects and return employye details");
				Console.Write("\n" + "4.search by department name and print projects related to it");
				Console.Write("\n" + "5.exit");
				Console.WriteLine("\n" + "ENTER YOUR CHOICE");
				ch = int.Parse(Console.ReadLine());
				string filename1 = @"C:\Users\Chandana T M\Desktop\empfile.txt";
				string filename2 = @"C:\Users\Chandana T M\Desktop\deptfile.txt";
				string filename3 = @"C:\Users\Chandana T M\Desktop\projfile.txt";
				int value1 = 1;    //this value is used to implement logic with filename1.
				int value2 = 2;    //this value is used to implement logic with filename2.
				int value3 = 3;   //this value is used to implement logic with filename3.
				switch (ch)
				{
					case 1:
						int p = 1;
						while (p == 1)
						{
							Console.WriteLine("1.insert employee 2.department 3. projects 4. exit from insert option");
							int ch1 = int.Parse(Console.ReadLine());
							if (ch1 == 1)
								writefiles(filename1, ch1);  //calls writeline function passing filename1 and ch1
							else if (ch1 == 2)
								writefiles(filename2, ch1);  //calls writeline function passing filename2 and ch2
							else if (ch1 == 3)
								writefiles(filename3, ch1);  //calls writeline function passing filenamem and ch3
							else if (ch1 == 4)
								p = 0;
							else
								Console.WriteLine("ENTER THE CORRECT CHOICE");
						}
						break;
					case 5:
						flag = 0; break;
					case 2:
						Console.WriteLine("ENTER THE DEPARTMENT NAME TO BE ENETERED");
						string val = Console.ReadLine();
						deptid1 = "";
						readfiles(filename2, value2, val);
						readfiles(filename1, value1, deptid1);
						break;
					case 3:
						Console.WriteLine("ENTER THE MANAGER EMPLOYEE ID TO BE SEARCHED");
						int ch2 = int.Parse(Console.ReadLine());
						mngrid = "";
						readfiles(filename3, value3, ch2.ToString());
						readfiles(filename1, value1, mngrid);
						break;
					case 4:
						Console.WriteLine("ENTER THE DEPARTMENT NAME TO BE ENETERED");
						string val1 = Console.ReadLine();
						deptid1 = "";
						readfiles(filename2, value2, val1);
						readfiles(filename3, value3, deptid1);
						break;
					default: Console.WriteLine("ENTER THE CORRCECT OPTION:"); break;
				}
			}
		}
		public static void writefiles(string filename, int ch1)
		{
			employee ob = new employee();

			StreamWriter sw = new StreamWriter(filename, true);
			using (sw)
			{
				switch (ch1)
				{
					case 1: ob.getemployee(); sw.WriteLine(ob.empdisplay()); break;        //calls the getemploye method and write the data to empfile
					case 2: ob.getdepartment(); sw.WriteLine(ob.deptdisplay()); break;   //calls the getemploye method and write the data to deptfile
					case 3: ob.getprojects(); sw.WriteLine(ob.projdisplay()); break;     //calls the getemploye method and write the data to projfile
					default: Console.WriteLine("WRONG CHOICE"); break;
				}
			}
			sw.Close();
		}

		public static void readfiles(string filename, int value, string key)
		{
			StreamReader sr1 = new StreamReader(filename, true);
			using (sr1)
			{
				string[] lines = File.ReadAllLines(filename);
				foreach (string line in lines)
				{
					string[] words = line.Split('|');
					foreach (string i in words)
					{
						// case 2 and 3 fetching department id
						// fetching department id from department file.
						if (value == 2 && key == words[1].Trim())
							deptid1 = words[0].Trim();

						// case2 printing empdetails
						// comparing fetched deptid1 in employee file and printing employee details
						if (value == 1 && key == words[4].Trim())
						{
							Console.WriteLine(words[0] + words[1] + words[2] + words[3] + words[4]);
							break;
						}

						//comparing the manager id in employee file with empids and printing employee details.
						else if (value == 1 && key == words[0].Trim())
						{
							Console.WriteLine(words[0] + words[1] + words[2] + words[3] + words[4]);
							break;
						}

						//case 4 printing project details.
						//comparing fetched deptid1 in projects file and printing projects details
						if (value == 3 && key == words[1].Trim())
						{
							Console.WriteLine(words[0] + words[1] + words[2] + words[3]);
							break;
						}

						//verifying wether manager id is in projects file or not
						else if (value == 3 && key == words[3].Trim())
						{
							mngrid = words[3].Trim();
						}
					}
				}
			}
			sr1.Close();
		}
	}
}
